<?php

namespace App\Controller;


use DateTime;
use App\Entity\Article;
use Doctrine\ORM\EntityManagerInterface;
use Symfony\Component\BrowserKit\Response;
use FOS\RestBundle\Controller\Annotations as Rest;
use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;

class AddController extends AbstractController
{

    /**
     * @Rest\Post("/articlesPost", name="liste_post")
     */
    public function articlePost(EntityManagerInterface $em)

    {

        $article = new Article();
        $article->setTitre('tennis');
        $article->setAuteur('moez');
        $article->setContenu('pas de match demain');
        $date = new DateTime('2021-11-11');
        $article->setDateDePublication($date);
        $em->persist($article);
        $em->flush();
        return new Response('bien poster!!!');
    }


    /**
     * @Rest\Put("/articlesPut/{id}", name="liste_put")
     */
    public function articlePut($id, EntityManagerInterface $em)

    {

        $article = new Article();
        $article = $this->getDoctrine()->getRepository(Article::class)->find($id);
        $article->setTitre('football');
        $article->setContenu('ohh la la');
        $article->setAuteur('abdou');
        $date = new \DateTime('2021-11-11');
        $article->setDateDePublication($date);
        $em->persist($article);
        $em->flush();
        return new Response('bien modifer!!!');
    }

    /**
     * @Rest\Delete("/articlesDelte/{id}", name="liste_delete")
     */
    public function articleDelete($id, EntityManagerInterface $em)

    {

        $article = new Article();
        $article = $this->getDoctrine()->getRepository(Article::class)->find($id);
        $em->remove($article);
        $em->flush();
        return new Response('bien suprimer!!!');
    }
}
